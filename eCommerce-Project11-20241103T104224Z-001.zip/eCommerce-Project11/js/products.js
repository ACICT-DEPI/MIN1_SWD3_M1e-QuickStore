const apiUrl = 'https://fakestoreapi.com/products';
let productsData = [];

fetch(apiUrl)
    .then(response => response.json())
    .then(products => {
        productsData = products; // حفظ جميع المنتجات
        displayProducts(productsData); // عرض جميع المنتجات
    })
    .catch(error => console.log('Error fetching products:', error));

// الصور الجديدة التي سيتم استخدامها بدلاً من صور الـ API
const newImages = [
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image1.1_dznswf.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039716/image1.11_xlamqj.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039582/image3_atcdfs.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image4_eovciw.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image5_jusmoc.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728115414/image8.8_flgq3w.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728115414/image9_qpwjsf.jpg"
];

const newImage = [
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image_vmbnfv.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image1_fljqrj.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039581/image3_2_zry0gt.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728040005/image4.4_ukuo6z.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728039582/image7_whsjmq.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728115414/image9.9_bjivdi.jpg",
    "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728115414/image8_rbwb5d.jpg"
];

// تصنيفات جديدة مخصصة بدلًا من الـ API
const customCategories = {
    "men's clothing": 'New',
    "electronics": 'Best Seller',
    "jewelery": 'Specials'
};

// دالة عرض جميع المنتجات
function displayProducts(products) {
    let productsContainer = '';

    products.forEach((product, i) => {
        const imageUrl = newImages[i % newImages.length]; // استخدام الصور المعدلة
        const image = newImage[i % newImage.length];
        const category = customCategories[product.category] || 'Other'; // تصنيف مخصص

        productsContainer += `
        <div class="card col-sm-6 col-md-4 col-lg-2">
            <div class="box">
                <img src="${imageUrl}" class="card-img-top" alt="${product.title}">
                <img src="${image}" class="card-img-top hover-image" alt="${products[i].title}">
            </div>
            <div class="hart">
                <a href=""><i class="fa-regular fa-heart"></i></a>
            </div>
            <div class="card-body data">
                <p class="card-text">${category}</p> <!-- عرض التصنيف المخصص -->
                <h5 class="card-title">${product.title.substring(0, 15)}...</h5>
                <div class="stars">
                    <a href=""><i class="fa-solid fa-star"></i></a>
                    <a href=""><i class="fa-solid fa-star"></i></a>
                    <a href=""><i class="fa-solid fa-star"></i></a>
                    <a href=""><i class="fa-solid fa-star"></i></a>
                    <a href=""><i class="fa-regular fa-star"></i></a>
                </div>
                <p class="card-text par">${product.price.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</p>
                <button class="btnn" onclick="addToCart('${product.id}')">Add to Cart</button>
                <div class="details">
                    <i class="fa-regular fa-eye"></i>
                    <a class="view" onclick="showProductDetails(${product.id})">View Details</a>
                </div>
            </div>
        </div>
        `;
    });

    document.getElementById("products").innerHTML = productsContainer;
}

// Show product details in modal
function showProductDetails(productId) {
    const product = productsData.find(p => p.id === productId);
    const imageUrl = newImages[(productId - 1) % newImages.length]; // استخدام الصورة المعدلة بناءً على ID المنتج

    if (product) {
        // Set values in the modal
        document.getElementById('modalProductImage').src = imageUrl; // استخدام الصورة المعدلة
        document.getElementById('modalProductTitle').innerText = product.title;
        document.getElementById('modalProductCategory').innerText = product.category;
        document.getElementById('modalProductPrice').innerText = product.price.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
        document.getElementById('modalProductDescription').innerText = product.description;

        // Show the modal
        const modal = new bootstrap.Modal(document.getElementById('productDetailsModal'));
        modal.show();
    }
}


// Filter products based on category
function filterProducts(category) {
    let filteredProducts = productsData;
    
    if (category !== 'all') {
        filteredProducts = productsData.filter(product => {
            return customCategories[product.category] === category;
        });
    }
    
    displayProducts(filteredProducts); // Display filtered products
}

// Add event listeners to category buttons
document.querySelectorAll('.category-btn').forEach(button => {
    button.addEventListener('click', () => {
        const category = button.getAttribute('data-category'); // Get the desired category
        
        // Update button state (active)
        document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        filterProducts(category); // Filter products on click
    });
});



// دالة إضافة المنتج إلى العربة (قيد التطوير)
function addToCart(productId) {
    console.log(`Product with ID ${productId} added to cart.`);
    // يمكنك إضافة منطق العربة هنا
}
