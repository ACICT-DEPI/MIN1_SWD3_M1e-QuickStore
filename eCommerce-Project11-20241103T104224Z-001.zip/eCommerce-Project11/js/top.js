
let topCateg = [];
let current = 0;
let displayLim = 5;

async function fetchProducts() {
    try {
        // استخدام الـ API الجديد الذي يحتوي على limit
        const response = await fetch('https://fakestoreapi.com/products?limit=7');
        const data = await response.json();
        products = data; // لا حاجة لعمل slice الآن
        displayProducts(current, displayLim); // عرض المنتجات
    } catch (error) {
        console.error("Error fetching products:", error);
    }
}

function displayProducts(index, limit) {
    let productsContainer = '';
    const newImages = [
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445726/laptop1.1_gqgj9z.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone1.1_zkmm9m.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445726/laptop2_krck9z.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445726/image12_z6oskp.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445726/phone2_c93cra.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445726/phone3.3_qchmix.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone4_yczcn5.jpg"
    ];
    const newImage = [
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/laptop1_fplyus.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone1_dwfgqi.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/laptop2.2_nynzk7.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1728116079/image12.12_ckshav.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone2.2_vsgvq4.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone3_stzljv.jpg",
        "https://res.cloudinary.com/dbjc13fxq/image/upload/v1729445727/phone4.4_vsjebo.jpg"
    ];

    for (let i = index; i < index + limit && i < products.length; i++) {
        const imageUrl = newImages[i % newImages.length];
        const image = newImage[i % newImage.length];
        productsContainer += `
            <div class="card col-sm-4 col-md-3 col-lg-2">
                <div class="box">
                    <img src="${imageUrl}" class="card-img-top" alt="${products[i].title}">
                    <img src="${image}" class="card-img-top hover-image" alt="${products[i].title}">
                </div>
                <div class="hart">
                    <a href=""><i class="fa-regular fa-heart"></i></a>
                </div>
                <div class="card-body data">
                    <p class="card-text">Smart Watch</p>
                    <h5 class="card-title">${products[i].title.substring(0, 15)}...</h5>
                    <div class="stars">
                        <a href=""><i class="fa-solid fa-star"></i></a>
                        <a href=""><i class="fa-solid fa-star"></i></a>
                        <a href=""><i class="fa-solid fa-star"></i></a>
                        <a href=""><i class="fa-solid fa-star"></i></a>
                        <a href=""><i class="fa-regular fa-star"></i></a>
                    </div>
                    <p class="card-text par">${products[i].price.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</p>
                    <button class="btnn" onclick="addToCart('${products[i].id}')">Add to Cart</button>
                    <div class="details">
                        <i class="fa-regular fa-eye"></i>
                        <a class="view" onclick="showProductDetails(${products[i].id})">View Details</a>
                    </div>
                </div>
            </div>
        `;
    }
    document.getElementById("topCateg").innerHTML = productsContainer;
}

function slideLeft() {
    if (current > 0) {
        current -= 1;
    } else {
        current = products.length - displayLim;
    }
    displayProducts(current, displayLim);
}

function slideRight() {
    if (current < products.length - displayLim) {
        current += 1;
    } else {
        current = 0;
    }
    displayProducts(current, displayLim);
}

fetchProducts();

// دالة إضافة المنتج إلى العربة (قيد التطوير)
function addToCart(productId) {
    console.log(`Product with ID ${productId} added to cart.`);
    // يمكنك إضافة منطق العربة هنا
}
