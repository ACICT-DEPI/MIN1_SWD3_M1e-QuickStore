document.getElementById('registerForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // جمع بيانات التسجيل
    const userData = {
        email: document.getElementById('email').value,
        username: document.getElementById('Username').value, // تأكدت هنا من إن الـ ID في HTML هو Username مش username
        password: document.getElementById('password').value,
        name: {
            firstname: document.getElementById('firstname').value,
            lastname: document.getElementById('lastname').value
        },
        address: {
            city: document.getElementById('city').value,
            zipcode: document.getElementById('zipcode').value,
            geolocation: {
                lat: '-37.3159',
                long: '81.1496'
            }
        },
        phone: "123-456-7890" // إذا ما فيش حقل phone، دي قيمة افتراضية
    };

    console.log('Registering user with data:', userData); // Debugging line

    // إرسال البيانات إلى API لتسجيل المستخدم
    fetch('https://fakestoreapi.com/users', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Registration failed with status ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Registration successful:', data);

        // عرض رسالة نجاح
        const messageElement = document.getElementById("message");
        messageElement.textContent = "User registered successfully!";
        messageElement.classList.add('success');
        messageElement.classList.remove('error');
        messageElement.style.display = 'block';

        // توجيه المستخدم لصفحة تسجيل الدخول
        setTimeout(() => {
            window.location.href = "login.html"; // هنا بتوجه المستخدم لصفحة تسجيل الدخول
        }, 1500); // تأخير بسيط لعرض الرسالة

    })
    .catch(error => {
        console.error('Error during registration:', error);

        // عرض رسالة خطأ
        const messageElement = document.getElementById("message");
        messageElement.textContent = "An error occurred during registration. Error details: " + error.message;
        messageElement.classList.add('error');
        messageElement.classList.remove('success');
        messageElement.style.display = 'block';
    });
});
