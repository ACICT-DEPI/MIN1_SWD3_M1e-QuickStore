document.getElementById("loginButton").addEventListener("submit", function (event) {
    event.preventDefault();

    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    console.log('Attempting login with:', { username, password });

    fetch('https://fakestoreapi.com/auth/login', {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
        .then(res => {
            if (!res.ok) {
                throw new Error(`Login failed with status ${res.status}`);
            }
            return res.json();
        })
        .then(data => {
            const messageElement = document.getElementById("message");
            messageElement.style.display = 'block'; // إظهار الرسالة
            if (data.token) {
                console.log("Login successful: ", data);
                localStorage.setItem("token", data.token);
                messageElement.textContent = "Login successful!";
                messageElement.classList.add('success');
                messageElement.classList.remove('error');
                
                // توجيه المستخدم إلى الصفحة الرئيسية بعد تسجيل الدخول الناجح
                setTimeout(() => {
                    window.location.href = "../html/index.html"; // هنا ضع رابط الصفحة اللي عاوز توجه المستخدم ليها
                }, 1000); // تأخير بسيط لعرض الرسالة قبل الانتقال
            } else {
                console.error("Error: Token is null");
                messageElement.textContent = "Login failed. Please check your credentials.";
                messageElement.classList.add('error');
                messageElement.classList.remove('success');
            }
        })
        .catch(error => {
            const messageElement = document.getElementById("message");
            console.error("Error during login:", error);
            messageElement.style.display = 'block'; // إظهار الرسالة
            messageElement.textContent = "An error occurred while logging in. Error details: " + error.message;
            messageElement.classList.add('error');
            messageElement.classList.remove('success');
        });
});



// اختبار جلب المستخدمين للتأكد من أن المستخدم مسجل
fetch('https://fakestoreapi.com/users')
    .then(response => response.json())
    .then(users => {
        console.log('Registered users:', users);
        // يمكنك البحث عن المستخدم الذي قمت بتسجيله في قائمة المستخدمين هنا
    })
    .catch(error => {
        console.error('Error fetching users:', error);
    });